// src/app/player/[id]/PlayerProfileClient.tsx
'use client';

import { useState, useEffect } from 'react';
import AppShell from '@/components/layout/AppShell';
import Link     from 'next/link';
import { useAuth } from '@/components/auth/AuthProvider';
import {
  Loader2, AlertCircle, Shield, ArrowLeft,
  Trophy, Target, Zap, Star, TrendingUp,
  CheckCircle, ChevronRight, ArrowLeftRight, Download,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Props { id: string }

// ── Mini batting + bowling stat chips ─────────────────────
function MatchStatChips({ stats }: { stats: any }) {
  const { batting, bowling } = stats ?? {};
  const chips = [];

  if (batting) {
    const notOut = batting.dismissed === false ? '*' : '';
    chips.push(
      <span key="bat" className={cn(
        'inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border font-display font-semibold',
        batting.runs >= 50
          ? 'bg-score-wide/15 border-score-wide/30 text-score-wide'
          : batting.runs >= 30
          ? 'bg-white/5 border-pitch-border text-white'
          : 'bg-pitch-dark border-pitch-border text-slate-400'
      )}>
        🏏 {batting.runs}{notOut}
        <span className="font-normal text-slate-500">({batting.balls})</span>
        {batting.sixes > 0 && <span className="text-score-six ml-0.5">{batting.sixes}×6</span>}
        {batting.fours > 0 && <span className="text-score-four ml-0.5">{batting.fours}×4</span>}
      </span>
    );
  }

  if (bowling) {
    chips.push(
      <span key="bowl" className={cn(
        'inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full border font-display font-semibold',
        bowling.wickets >= 3
          ? 'bg-score-wicket/15 border-score-wicket/30 text-score-wicket'
          : bowling.wickets > 0
          ? 'bg-white/5 border-pitch-border text-white'
          : 'bg-pitch-dark border-pitch-border text-slate-400'
      )}>
        ⚾ {bowling.wickets}/{bowling.runs}
        <span className="font-normal text-slate-500">({bowling.overs})</span>
      </span>
    );
  }

  if (chips.length === 0) {
    chips.push(
      <span key="dnb" className="text-xs text-slate-600 italic">Did not bat/bowl</span>
    );
  }

  return <div className="flex flex-wrap gap-1.5 mt-2">{chips}</div>;
}

export default function PlayerProfileClient({ id }: Props) {
  const { user }  = useAuth();
  const [data,    setData]     = useState<any>(null);
  const [loading, setLoading]  = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [claimMsg, setClaimMsg] = useState('');
  const [tab,     setTab]      = useState<'batting' | 'bowling' | 'matches'>('batting');
  const [exporting, setExporting] = useState(false);

  const handleExport = async (fmt: 'csv' | 'pdf') => {
    setExporting(true);
    try {
      if (fmt === 'csv') {
        const res  = await fetch(`/api/player/${id}/export?format=csv`);
        const blob = await res.blob();
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href = url; a.download = `${player?.name ?? 'player'}_stats.csv`;
        a.click(); URL.revokeObjectURL(url);
      } else {
        // PDF: fetch JSON data then generate client-side
        const res  = await fetch(`/api/player/${id}/export?format=pdf`);
        const json = await res.json();
        const rows = json.matches ?? [];
        const lines: string[] = [
          `ScoreXI Stats Export — ${json.player.name}`,
          `Matches: ${json.player.stats?.matchesPlayed ?? 0}  |  Runs: ${json.player.stats?.totalRuns ?? 0}  |  Wickets: ${json.player.stats?.totalWickets ?? 0}`,
          '',
          'Date,Match,Bat Runs,Bat Balls,4s,6s,Dismissal,Bowl Overs,Wickets,Runs Given',
          ...rows.map((r: any) => `${r.date},"${r.match}",${r.bat_runs},${r.bat_balls},${r.bat_4s},${r.bat_6s},${r.dismissal},${r.bowl_overs},${r.bowl_wickets},${r.bowl_runs}`),
        ];
        const blob = new Blob([lines.join('\n')], { type: 'text/csv' });
        const url  = URL.createObjectURL(blob);
        const a    = document.createElement('a');
        a.href = url; a.download = `${json.player.name}_stats_full.csv`;
        a.click(); URL.revokeObjectURL(url);
      }
    } finally { setExporting(false); }
  };

  useEffect(() => {
    fetch(`/api/player/${id}`)
      .then(r => r.json())
      .then(j => { if (j.success) setData(j.data); })
      .finally(() => setLoading(false));
  }, [id]);

  const handleClaim = async () => {
    setClaiming(true);
    const res  = await fetch(`/api/player/${id}/claim`, { method: 'POST' });
    const json = await res.json();
    if (json.success) {
      setClaimMsg('Profile claimed! Your stats are now linked.');
      setData((d: any) => ({ ...d, player: { ...d.player, isClaimed: true } }));
    } else {
      setClaimMsg(json.error || 'Claim failed');
    }
    setClaiming(false);
  };

  if (loading) return (
    <AppShell>
      <div className="flex items-center justify-center min-h-[60vh]">
        <Loader2 size={28} className="animate-spin text-brand-400" />
      </div>
    </AppShell>
  );

  if (!data) return (
    <AppShell>
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <AlertCircle size={36} className="text-score-wicket mx-auto mb-3" />
        <p className="text-white font-display font-bold text-xl mb-2">Player Not Found</p>
        <Link href="/players" className="btn-secondary mt-3 inline-block">← Players</Link>
      </div>
    </AppShell>
  );

  const { player, derived, recentMatches } = data;
  const { batting, bowling } = derived;
  const isOwner  = user?.claimedPlayerId === id || user?.claimedPlayerId === player._id;
  const canClaim = user && !user.isGuest && !player.isClaimed && !user.claimedPlayerId;

  return (
    <AppShell>
      <div className="max-w-3xl mx-auto px-4 py-5">

        {/* Back */}
        <Link href="/players" className="btn-ghost flex items-center gap-1.5 text-sm mb-4 w-fit">
          <ArrowLeft size={15} /> Players
        </Link>

        {/* Profile header */}
        <div className="card p-5 mb-4 relative overflow-hidden">
          <div className="absolute inset-0 bg-live-pulse pointer-events-none opacity-50" />
          <div className="relative flex items-start gap-4">
            {/* Avatar */}
            <div className="w-16 h-16 bg-gradient-to-br from-brand-600 to-brand-400 rounded-2xl
                            flex items-center justify-center flex-shrink-0 shadow-lg shadow-brand-500/30">
              <span className="font-display font-bold text-white text-2xl">
                {player.name[0].toUpperCase()}
              </span>
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="font-display font-bold text-xl sm:text-2xl text-white">
                  {player.name}
                </h1>
                {player.isClaimed && (
                  <span className="inline-flex items-center gap-1 text-brand-400 text-xs
                                   bg-brand-500/10 border border-brand-500/20 px-2 py-0.5 rounded-full">
                    <CheckCircle size={10} /> Verified
                  </span>
                )}
                {isOwner && (
                  <span className="inline-flex items-center gap-1 text-score-wide text-xs
                                   bg-score-wide/10 border border-score-wide/20 px-2 py-0.5 rounded-full">
                    <Shield size={10} /> You
                  </span>
                )}
              </div>
              {player.username && (
                <p className="text-slate-400 text-sm mt-0.5">@{player.username}</p>
              )}
              <p className="text-slate-500 text-xs mt-1">
                {player.stats.matchesPlayed} matches played
              </p>
            </div>

            {isOwner && (
              <div className="flex items-center gap-2 flex-shrink-0">
                <Link href={`/players/compare?a=${id}`}
                  className="btn-ghost py-1.5 px-3 text-xs flex items-center gap-1">
                  <ArrowLeftRight size={12} /> Compare
                </Link>
                <Link href="/profile" className="btn-secondary py-1.5 px-3 text-xs flex-shrink-0">
                  Edit
                </Link>
              </div>
            )}
            {!isOwner && (
              <Link href={`/players/compare?a=${id}`}
                className="btn-ghost py-1.5 px-3 text-xs flex items-center gap-1 flex-shrink-0">
                <ArrowLeftRight size={12} /> Compare
              </Link>
            )}
          </div>

          {/* Claim CTA */}
          {canClaim && (
            <div className="mt-4 p-3 bg-score-wide/10 border border-score-wide/25 rounded-xl">
              <p className="text-sm text-white font-semibold mb-1">Is this you?</p>
              <p className="text-xs text-slate-400 mb-2">
                Claim this profile to own your stats.
              </p>
              {claimMsg ? (
                <p className={cn('text-sm font-semibold',
                  claimMsg.includes('claimed') ? 'text-brand-400' : 'text-score-wicket'
                )}>{claimMsg}</p>
              ) : (
                <button onClick={handleClaim} disabled={claiming}
                  className="btn-primary py-1.5 px-4 text-sm flex items-center gap-1.5">
                  {claiming
                    ? <><Loader2 size={14} className="animate-spin" /> Claiming...</>
                    : <><CheckCircle size={14} /> Claim Profile</>
                  }
                </button>
              )}
            </div>
          )}

          {!user && !player.isClaimed && (
            <div className="mt-4 p-3 bg-pitch-border/50 rounded-xl flex items-center justify-between">
              <p className="text-xs text-slate-400">This profile is unclaimed.</p>
              <Link href={`/auth/register?claim=${id}`}
                className="text-brand-400 text-xs font-semibold hover:text-brand-300">
                Claim it →
              </Link>
            </div>
          )}
        </div>

        {/* Quick stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          {[
            { label: 'Runs',       value: player.stats.totalRuns,     icon: Trophy,     color: 'text-score-wide'   },
            { label: 'Wickets',    value: player.stats.totalWickets,  icon: Target,     color: 'text-score-wicket' },
            { label: 'Best Score', value: player.stats.highestScore,  icon: Star,       color: 'text-score-six'    },
            { label: 'Matches',    value: player.stats.matchesPlayed, icon: TrendingUp, color: 'text-brand-400'    },
          ].map(s => (
            <div key={s.label} className="card p-4 text-center">
              <s.icon size={16} className={cn('mx-auto mb-1', s.color)} />
              <p className={cn('font-display font-bold text-2xl tabular', s.color)}>{s.value}</p>
              <p className="text-slate-500 text-xs">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-pitch-card rounded-xl border border-pitch-border mb-4">
          {(['batting', 'bowling', 'matches'] as const).map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={cn(
                'flex-1 py-2 rounded-lg text-sm font-display font-semibold capitalize transition-all',
                tab === t ? 'bg-brand-500 text-white' : 'text-slate-400 hover:text-white'
              )}
            >
              {t}
            </button>
          ))}
        </div>


        {/* Export buttons — visible to profile owner */}
        {isOwner && player.stats.matchesPlayed > 0 && (
          <div className="flex items-center gap-2 mb-4">
            <span className="text-xs text-slate-500 font-semibold uppercase tracking-wider flex items-center gap-1">
              <Download size={11} /> Export Stats
            </span>
            <button
              onClick={() => handleExport('csv')}
              disabled={exporting}
              className="btn-ghost py-1 px-3 text-xs flex items-center gap-1"
            >
              {exporting ? <Loader2 size={11} className="animate-spin" /> : null}
              CSV
            </button>
            <button
              onClick={() => handleExport('pdf')}
              disabled={exporting}
              className="btn-ghost py-1 px-3 text-xs"
            >
              PDF
            </button>
          </div>
        )}

        {/* Batting stats */}
        {tab === 'batting' && (
          <div className="card p-5 animate-fade-in">
            <h3 className="font-display font-bold text-white mb-4 flex items-center gap-2">
              <Trophy size={16} className="text-score-wide" /> Batting Career
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
              {[
                { label: 'Total Runs',    value: player.stats.totalRuns                         },
                { label: 'Average',       value: batting.average     || '—'                     },
                { label: 'Strike Rate',   value: batting.strikeRate  ? `${batting.strikeRate}` : '—' },
                { label: 'Highest Score', value: player.stats.highestScore                       },
                { label: 'Fours (4s)',    value: player.stats.totalFours                         },
                { label: 'Sixes (6s)',    value: player.stats.totalSixes                         },
                { label: 'Balls Faced',   value: player.stats.totalBallsFaced                    },
                { label: 'Not Outs',      value: player.stats.notOuts                            },
                { label: 'Innings',       value: batting.innings                                 },
              ].map(s => (
                <div key={s.label} className="bg-pitch-dark rounded-xl p-3">
                  <p className="text-slate-500 text-xs mb-1">{s.label}</p>
                  <p className="font-display font-bold text-lg text-white tabular">{s.value}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Bowling stats */}
        {tab === 'bowling' && (
          <div className="card p-5 animate-fade-in">
            <h3 className="font-display font-bold text-white mb-4 flex items-center gap-2">
              <Zap size={16} className="text-score-wicket" /> Bowling Career
            </h3>
            {player.stats.totalWickets === 0 ? (
              <p className="text-slate-500 text-sm">No bowling stats yet.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {[
                  { label: 'Wickets',       value: player.stats.totalWickets    },
                  { label: 'Best Bowling',  value: bowling.bestBowling           },
                  { label: 'Economy',       value: bowling.economy    || '—'     },
                  { label: 'Average',       value: bowling.average    || '—'     },
                  { label: 'Strike Rate',   value: bowling.strikeRate || '—'     },
                  { label: 'Overs',         value: bowling.overs                 },
                  { label: 'Runs Conceded', value: player.stats.totalRunsConceded },
                ].map(s => (
                  <div key={s.label} className="bg-pitch-dark rounded-xl p-3">
                    <p className="text-slate-500 text-xs mb-1">{s.label}</p>
                    <p className="font-display font-bold text-lg text-white tabular">{s.value}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Match history with per-match stats */}
        {tab === 'matches' && (
          <div className="space-y-3 animate-fade-in">
            <p className="text-xs text-slate-500 uppercase tracking-wider font-semibold px-1">
              Recent Matches — {player.name}'s performances
            </p>
            {recentMatches.length === 0 ? (
              <div className="card p-8 text-center">
                <p className="text-slate-400">No public match history yet.</p>
              </div>
            ) : recentMatches.map((m: any) => (
              <Link key={m._id} href={`/match/${m._id}`} className="block">
                <div className="card-hover p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <p className="font-display font-semibold text-white text-sm truncate">
                        {m.title || `${m.teamA.name} vs ${m.teamB.name}`}
                      </p>
                      <p className="text-slate-500 text-xs mt-0.5">
                        {m.teamA.name} vs {m.teamB.name} · {m.totalOvers} overs
                      </p>

                      {/* Per-match stat chips */}
                      <MatchStatChips stats={m.playerStats} />
                    </div>

                    <div className="text-right flex-shrink-0 ml-2">
                      {m.result && (
                        <p className="text-xs text-brand-400 font-semibold whitespace-nowrap">
                          {m.result.winnerName} won
                        </p>
                      )}
                      <ChevronRight size={14} className="text-slate-600 ml-auto mt-1" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

      </div>
    </AppShell>
  );
}