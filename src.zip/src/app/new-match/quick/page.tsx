// src/app/new-match/quick/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/layout/AppShell';
import { Loader2, Play, Zap, Settings, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { saveHostedMatch } from '@/lib/hostedMatches';

const OVER_OPTIONS = [2, 4, 5, 6, 8, 10, 12, 15, 20];

// ── Player name row ───────────────────────────────────────
// Shows a numbered input row for each player slot.
// Left blank = auto-number (e.g. "Warriors 1"); filled = use that name.
function PlayerNameInputs({
  teamName,
  names,
  onChange,
}: {
  teamName: string;
  names:    string[];
  onChange: (idx: number, val: string) => void;
}) {
  return (
    <div className="space-y-1.5 mt-3">
      {names.map((n, i) => (
        <div key={i} className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-full bg-brand-500/10 border border-brand-500/20
                          flex items-center justify-center text-[10px] font-bold text-brand-400 flex-shrink-0">
            {i + 1}
          </div>
          <input
            type="text"
            className="input-field py-1.5 text-sm"
            placeholder={`${teamName} ${i + 1}`}
            value={n}
            onChange={e => onChange(i, e.target.value)}
            maxLength={40}
          />
        </div>
      ))}
    </div>
  );
}

const PLAYER_COUNT = 11;
const makeNames = (n: number) => Array(n).fill('');

export default function QuickMatchPage() {
  const router = useRouter();

  const [form, setForm] = useState({
    teamAName:  '',
    teamBName:  '',
    totalOvers: 6,
    tossWonBy:  'teamA' as 'teamA' | 'teamB',
    tossChoice: 'bat'   as 'bat' | 'bowl',
    wideRuns:   1       as 0 | 1,
    allowSinglePlayerBat: false,
  });

  // Task 16 — optional real player names per team
  const [showPlayerNames,  setShowPlayerNames]  = useState(false);
  const [teamANames,       setTeamANames]       = useState<string[]>(makeNames(PLAYER_COUNT));
  const [teamBNames,       setTeamBNames]       = useState<string[]>(makeNames(PLAYER_COUNT));
  const [advancedOpen,     setAdvancedOpen]     = useState(false);

  const [submitting, setSubmitting] = useState(false);
  const [error,      setError]      = useState('');

  const update = (k: string, v: any) => setForm(f => ({ ...f, [k]: v }));

  const updateTeamAName = (i: number, val: string) => {
    setTeamANames(prev => { const n = [...prev]; n[i] = val; return n; });
  };
  const updateTeamBName = (i: number, val: string) => {
    setTeamBNames(prev => { const n = [...prev]; n[i] = val; return n; });
  };

  const handleStart = async () => {
    if (!form.teamAName.trim() || !form.teamBName.trim()) {
      setError('Enter both team names'); return;
    }
    setSubmitting(true); setError('');
    try {
      // Build player arrays: use typed name if filled, else auto-number
      const makePlayers = (teamName: string, names: string[]) =>
        names.map((n, i) => ({ name: n.trim() || `${teamName} ${i + 1}` }));

      const res  = await fetch('/api/matches', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({
          teamAName:    form.teamAName.trim(),
          teamBName:    form.teamBName.trim(),
          totalOvers:   form.totalOvers,
          visibility:   'private',
          tossWonBy:    form.tossWonBy,
          tossChoice:   form.tossChoice,
          teamAPlayers: makePlayers(form.teamAName.trim(), teamANames),
          teamBPlayers: makePlayers(form.teamBName.trim(), teamBNames),
          isQuickMatch: true,
          settings: {
            wideRuns:             form.wideRuns,
            allowSinglePlayerBat: form.allowSinglePlayerBat,
          },
        }),
      });
      const json = await res.json();
      if (json.success) {
        const { matchId, shareToken } = json.data;
        const title = `${form.teamAName} vs ${form.teamBName}`;
        saveHostedMatch(matchId, shareToken, title);
        router.push(`/scoring/${matchId}?token=${shareToken}&quick=1`);
      } else {
        setError(json.error || 'Failed to create match');
      }
    } catch { setError('Network error'); }
    finally  { setSubmitting(false); }
  };

  const battingTeam =
    form.tossWonBy === 'teamA'
      ? (form.tossChoice === 'bat' ? form.teamAName || 'Team A' : form.teamBName || 'Team B')
      : (form.tossChoice === 'bat' ? form.teamBName || 'Team B' : form.teamAName || 'Team A');

  return (
    <AppShell>
      <div className="max-w-md mx-auto px-4 py-6">

        {/* Header */}
        <div className="mb-6 text-center">
          <div className="inline-flex items-center gap-2 bg-brand-500/10 border border-brand-500/25
                          rounded-full px-4 py-2 mb-3">
            <Zap size={14} className="text-brand-400" />
            <span className="text-brand-400 text-sm font-semibold">Quick Match</span>
          </div>
          <h1 className="font-display font-bold text-2xl text-white mb-1">Start in 30 seconds</h1>
          <p className="text-slate-400 text-sm">
            Enter team names and go. Optionally add player names below.
          </p>
        </div>

        <div className="space-y-4">

          {/* Team names */}
          <div className="card p-4 space-y-3">
            <div>
              <label className="text-xs text-slate-400 mb-1.5 block font-semibold uppercase tracking-wide">
                Team A Name
              </label>
              <input type="text" className="input-field text-base" placeholder="e.g. Warriors"
                value={form.teamAName} onChange={e => update('teamAName', e.target.value)}
                maxLength={30} autoFocus />
            </div>
            <div>
              <label className="text-xs text-slate-400 mb-1.5 block font-semibold uppercase tracking-wide">
                Team B Name
              </label>
              <input type="text" className="input-field text-base" placeholder="e.g. Lions"
                value={form.teamBName} onChange={e => update('teamBName', e.target.value)}
                maxLength={30} />
            </div>
          </div>

          {/* Overs */}
          <div className="card p-4">
            <label className="text-xs text-slate-400 mb-2 block font-semibold uppercase tracking-wide">
              Overs
            </label>
            <div className="flex flex-wrap gap-2">
              {OVER_OPTIONS.map(o => (
                <button key={o} onClick={() => update('totalOvers', o)}
                  className={cn('px-3 py-2 rounded-xl border text-sm font-display font-bold transition-all',
                    form.totalOvers === o
                      ? 'bg-brand-500 border-brand-500 text-white'
                      : 'border-pitch-border text-slate-400 hover:border-brand-500/50 hover:text-white')}>
                  {o}
                </button>
              ))}
            </div>
          </div>

          {/* Toss */}
          <div className="card p-4 space-y-3">
            <p className="text-xs text-slate-400 font-semibold uppercase tracking-wide">Toss</p>
            <div>
              <p className="text-xs text-slate-500 mb-1.5">Won by</p>
              <div className="grid grid-cols-2 gap-2">
                {(['teamA', 'teamB'] as const).map(t => (
                  <button key={t} onClick={() => update('tossWonBy', t)}
                    className={cn('py-2 px-3 rounded-xl border text-sm font-semibold transition-all',
                      form.tossWonBy === t
                        ? 'bg-brand-500/20 border-brand-500 text-brand-400'
                        : 'border-pitch-border text-slate-400 hover:border-brand-500/30')}>
                    {t === 'teamA' ? (form.teamAName || 'Team A') : (form.teamBName || 'Team B')}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <p className="text-xs text-slate-500 mb-1.5">Chose to</p>
              <div className="grid grid-cols-2 gap-2">
                {(['bat', 'bowl'] as const).map(c => (
                  <button key={c} onClick={() => update('tossChoice', c)}
                    className={cn('py-2 px-3 rounded-xl border text-sm font-semibold capitalize transition-all',
                      form.tossChoice === c
                        ? 'bg-brand-500/20 border-brand-500 text-brand-400'
                        : 'border-pitch-border text-slate-400 hover:border-brand-500/30')}>
                    {c}
                  </button>
                ))}
              </div>
            </div>
            {form.teamAName && form.teamBName && (
              <p className="text-xs text-brand-400 bg-brand-500/10 rounded-xl px-3 py-2">
                🏏 <strong>{battingTeam}</strong> bats first
              </p>
            )}
          </div>

          {/* Task 16 — Optional real player names */}
          <div className="border border-pitch-border rounded-xl overflow-hidden">
            <button type="button"
              onClick={() => setShowPlayerNames(o => !o)}
              className="w-full flex items-center justify-between px-4 py-3
                         text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              <span className="flex items-center gap-2 text-sm font-semibold">
                👤 Add Player Names (optional)
              </span>
              <ChevronDown size={14} className={cn('transition-transform', showPlayerNames && 'rotate-180')} />
            </button>

            {showPlayerNames && (
              <div className="border-t border-pitch-border bg-pitch-dark/40 px-4 py-4 space-y-5">
                <p className="text-xs text-slate-500">
                  Leave blank to use auto-numbers. You can also rename players later during scoring.
                </p>

                <div>
                  <p className="text-sm font-semibold text-white mb-1">
                    {form.teamAName || 'Team A'}
                  </p>
                  <PlayerNameInputs
                    teamName={form.teamAName || 'Team A'}
                    names={teamANames}
                    onChange={updateTeamAName}
                  />
                </div>

                <div>
                  <p className="text-sm font-semibold text-white mb-1">
                    {form.teamBName || 'Team B'}
                  </p>
                  <PlayerNameInputs
                    teamName={form.teamBName || 'Team B'}
                    names={teamBNames}
                    onChange={updateTeamBName}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Advanced settings */}
          <div className="border border-pitch-border rounded-xl overflow-hidden">
            <button type="button"
              onClick={() => setAdvancedOpen(o => !o)}
              className="w-full flex items-center justify-between px-4 py-3
                         text-slate-400 hover:text-white hover:bg-white/5 transition-all">
              <span className="flex items-center gap-2 text-sm font-semibold">
                <Settings size={14} /> Advanced Settings
              </span>
              <ChevronDown size={14} className={cn('transition-transform', advancedOpen && 'rotate-180')} />
            </button>

            {advancedOpen && (
              <div className="border-t border-pitch-border bg-pitch-dark/40 px-4 py-4 space-y-4">
                {/* Wide runs */}
                <div>
                  <label className="text-sm text-slate-300 font-semibold block mb-1">Wide Ball Runs</label>
                  <p className="text-xs text-slate-500 mb-2">How many runs does a wide add?</p>
                  <div className="flex gap-2">
                    {([0, 1] as const).map(v => (
                      <button key={v} type="button" onClick={() => update('wideRuns', v)}
                        className={cn('flex-1 py-2 rounded-xl border-2 font-display font-bold text-lg transition-all',
                          form.wideRuns === v
                            ? 'border-brand-500 bg-brand-500/15 text-white'
                            : 'border-pitch-border text-slate-500 hover:border-pitch-muted hover:text-slate-300')}>
                        +{v}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Single player bat */}
                <div className="flex items-center justify-between">
                  <div>
                    <label className="text-sm text-slate-300 font-semibold block">
                      Allow Single-Player Batting
                    </label>
                    <p className="text-xs text-slate-500">One person can bat alone</p>
                  </div>
                  <button type="button"
                    onClick={() => update('allowSinglePlayerBat', !form.allowSinglePlayerBat)}
                    className={cn('w-12 h-6 rounded-full transition-all flex-shrink-0 relative',
                      form.allowSinglePlayerBat ? 'bg-brand-500' : 'bg-pitch-border')}>
                    <span className={cn('absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-all',
                      form.allowSinglePlayerBat ? 'left-[26px]' : 'left-0.5')} />
                  </button>
                </div>
              </div>
            )}
          </div>

          {error && (
            <div className="bg-score-wicket/10 border border-score-wicket/30 rounded-xl px-4 py-3">
              <p className="text-score-wicket text-sm">{error}</p>
            </div>
          )}

          <button
            onClick={handleStart}
            disabled={submitting || !form.teamAName || !form.teamBName}
            className={cn('btn-primary w-full flex items-center justify-center gap-2 py-4 text-lg',
              (!form.teamAName || !form.teamBName) && 'opacity-40')}>
            {submitting
              ? <><Loader2 size={20} className="animate-spin" /> Creating...</>
              : <><Play size={20} /> Start Scoring Now</>
            }
          </button>

          <p className="text-center text-slate-500 text-xs">
            Unnamed players will be "Team A 1", "Team A 2" etc.
            You can rename them anytime during the match.
          </p>
        </div>
      </div>
    </AppShell>
  );
}