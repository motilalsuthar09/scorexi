// src/app/api/match/[id]/route.ts
// ============================================================
// GET  /api/match/[id]   — get full match + scorecard
// PATCH /api/match/[id]  — update match (visibility, complete)
//
// FIXES:
//   FIX 9 — dismissalDesc is now human-readable (c Rohit b Bumrah)
//   FIX 8 — maiden over detection now per-actual-over (not per-bowler total)
// ============================================================
import { NextRequest } from 'next/server';
import { connectDB }   from '@/lib/db';
import Match           from '@/models/Match';
import Innings         from '@/models/Innings';
import Ball            from '@/models/Ball';
import Player          from '@/models/Player';
import { apiSuccess, apiError, formatBallDisplay } from '@/lib/utils';

// FIX 9: Build Cricbuzz-style dismissal text
function buildDismissalDesc(
  dismissalType: string | null,
  bowlerName:    string,
  fielderName:   string | null,
): string {
  if (!dismissalType) return 'out';
  switch (dismissalType) {
    case 'bowled':     return `b ${bowlerName}`;
    case 'caught':     return fielderName ? `c ${fielderName} b ${bowlerName}` : `c & b ${bowlerName}`;
    case 'lbw':        return `lbw b ${bowlerName}`;
    case 'stumped':    return fielderName ? `st ${fielderName} b ${bowlerName}` : `st b ${bowlerName}`;
    case 'run_out':    return fielderName ? `run out (${fielderName})` : 'run out';
    case 'hit_wicket': return `hit wkt b ${bowlerName}`;
    case 'retired':    return 'retired hurt';
    default:           return dismissalType.replace(/_/g, ' ');
  }
}

export async function GET(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id }  = params;
    const token   = req.nextUrl.searchParams.get('token');

    await connectDB();

    const match = await Match.findById(id).lean();
    if (!match) return apiError('Match not found', 404);

    // Access control: private matches need token
    if (match.visibility === 'private') {
      if (!token || token !== match.shareToken) {
        return apiError('Access denied. Share link required.', 403);
      }
    }

    // Load both innings
    const inningsArr = await Innings.find({ matchId: id })
      .sort({ inningsNumber: 1 })
      .lean();

    // Load all players referenced in match
    const allPlayerIds = [
      ...match.teamA.playerIds,
      ...match.teamB.playerIds,
    ].map(String);

    const players = await Player.find({ _id: { $in: allPlayerIds } })
      .select('name username profilePic')
      .lean();

    const playerMap = Object.fromEntries(players.map(p => [p._id.toString(), p]));

    // Build scorecard for each innings
    const scorecards = await Promise.all(
      inningsArr.map(async (innings) => {
        const balls = await Ball.find({ inningsId: innings._id })
          .sort({ totalBallsInInnings: 1 })
          .lean();

        // ── Batting scorecard ─────────────────────────────
        const battingMap = new Map<string, {
          runs: number; balls: number; fours: number; sixes: number;
          dismissed: boolean; dismissalDesc: string;
        }>();

        const battingTeamPlayerIds = (
          innings.battingTeam === 'teamA' ? match.teamA.playerIds : match.teamB.playerIds
        ).map(String);

        for (const pid of battingTeamPlayerIds) {
          battingMap.set(pid, { runs: 0, balls: 0, fours: 0, sixes: 0, dismissed: false, dismissalDesc: '' });
        }

        // ── Bowling scorecard ─────────────────────────────
        // FIX 8: Track maidens per actual over-number, not per-bowler total balls
        // Key: `${bowlerId}:${overNumber}` → runs in that over
        const bowlingMap = new Map<string, {
          runs: number; balls: number; wickets: number; maidens: number;
        }>();
        // Per-over run tracking for maiden detection
        const overRunMap = new Map<string, number>(); // key: `${bowlerId}:${overNumber}`

        // Fall of wickets
        const fowList: { wicket: number; runs: number; over: string; name: string }[] = [];
        let wicketCount = 0;

        for (const ball of balls) {
          const bid  = ball.batsmanId.toString();
          const bwid = ball.bowlerId.toString();

          // ── Batting ───────────────────────────────────────
          const bs = battingMap.get(bid);
          if (bs) {
            if (ball.isLegalDelivery) bs.balls++;
            // Runs credited to batsman: not for wide/bye/leg-bye
            if (!ball.extraType || ball.extraType === 'no_ball') {
              bs.runs += ball.runsOffBat;
              if (ball.runsOffBat === 4) bs.fours++;
              if (ball.runsOffBat === 6) bs.sixes++;
            }
            if (ball.isWicket && ball.dismissedPlayerId?.toString() === bid) {
              bs.dismissed = true;
              // FIX 9: Human-readable dismissal text
              const bowlerName = playerMap[bwid]?.name ?? 'Unknown';
              const fielderName = ball.fielderIds?.[0]
                ? (playerMap[ball.fielderIds[0].toString()]?.name ?? null)
                : null;
              bs.dismissalDesc = buildDismissalDesc(ball.dismissalType, bowlerName, fielderName);
            }
          }

          // ── Bowling ───────────────────────────────────────
          if (!bowlingMap.has(bwid)) {
            bowlingMap.set(bwid, { runs: 0, balls: 0, wickets: 0, maidens: 0 });
          }
          const bw = bowlingMap.get(bwid)!;
          bw.runs += ball.runsOffBat + ball.extras;
          if (ball.isLegalDelivery) bw.balls++;
          if (ball.isWicket) bw.wickets++;

          // FIX 8: Maiden tracking per actual over number
          if (ball.isLegalDelivery) {
            const overKey = `${bwid}:${ball.overNumber}`;
            overRunMap.set(overKey, (overRunMap.get(overKey) ?? 0) + ball.runsOffBat + ball.extras);
          }

          // ── Fall of wicket ────────────────────────────────
          if (ball.isWicket) {
            wicketCount++;
            const over       = `${ball.overNumber}.${ball.ballInOver + 1}`;
            const dismissed  = ball.dismissedPlayerId
              ? playerMap[ball.dismissedPlayerId.toString()]?.name ?? 'Unknown'
              : '';
            fowList.push({ wicket: wicketCount, runs: ball.inningsRunsAfter, over, name: dismissed });
          }
        }

        // FIX 8: Count maidens after processing all balls
        // A maiden over = an over where a bowler delivered all 6 legal balls and conceded 0 runs
        const ballsPerOverByBowler = new Map<string, number>(); // `${bowlerId}:${overNumber}` → ball count
        for (const ball of balls) {
          if (!ball.isLegalDelivery) continue;
          const k = `${ball.bowlerId.toString()}:${ball.overNumber}`;
          ballsPerOverByBowler.set(k, (ballsPerOverByBowler.get(k) ?? 0) + 1);
        }
        for (const [key, ballCount] of ballsPerOverByBowler.entries()) {
          if (ballCount === 6) {
            const runsInOver = overRunMap.get(key) ?? 0;
            if (runsInOver === 0) {
              const bwid = key.split(':')[0];
              const bw   = bowlingMap.get(bwid);
              if (bw) bw.maidens++;
            }
          }
        }

        // ── Recent balls (last 12 for over display) ───────
        const recentBalls = balls.slice(-12).map(b => formatBallDisplay(
          b.runsOffBat, b.extraType, b.isWicket
        ));

        return {
          innings,
          battingScorecard: battingTeamPlayerIds.map(pid => ({
            player: playerMap[pid] ?? { _id: pid, name: 'Unknown' },
            ...battingMap.get(pid) ?? { runs: 0, balls: 0, fours: 0, sixes: 0, dismissed: false, dismissalDesc: '' },
            isStriker: innings.currentStrikerId?.toString() === pid,
            batting:   [innings.currentStrikerId?.toString(), innings.currentNonStrikerId?.toString()].includes(pid),
          })),
          bowlingScorecard: Array.from(bowlingMap.entries()).map(([pid, stats]) => ({
            player: playerMap[pid] ?? { _id: pid, name: 'Unknown' },
            ...stats,
            isBowling: innings.currentBowlerId?.toString() === pid,
          })),
          fallOfWickets: fowList,
          recentBalls,
        };
      })
    );

    const { shareToken: _st, ...matchSafe } = match as typeof match & { shareToken: string };

    return apiSuccess({
      match: {
        ...matchSafe,
        shareToken: match.visibility === 'private' ? match.shareToken : undefined,
        shareUrl: `${process.env.NEXT_PUBLIC_APP_URL}/match/${match._id}?token=${match.shareToken}`,
      },
      playerMap,
      scorecards,
    });

  } catch (err) {
    console.error('[GET /api/match/[id]]', err);
    return apiError('Failed to load match', 500);
  }
}

// ─── PATCH /api/match/[id] ─────────────────────────────────
export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { id }  = params;
    const body    = await req.json();
    const { visibility, status } = body;

    await connectDB();

    const match = await Match.findById(id);
    if (!match) return apiError('Match not found', 404);

    if (visibility && ['public', 'private'].includes(visibility)) {
      match.visibility = visibility;
    }
    if (status === 'completed') {
      match.status = 'completed';
      match.completedAt = new Date();
    }
    if (status === 'innings_break') {
      match.status = 'innings_break';
      match.currentInnings = 2;
    }
    if (status === 'live') {
      match.status = 'live';
    }

    await match.save();
    return apiSuccess({ updated: true });
  } catch (err) {
    console.error('[PATCH /api/match/[id]]', err);
    return apiError('Failed to update match', 500);
  }
}